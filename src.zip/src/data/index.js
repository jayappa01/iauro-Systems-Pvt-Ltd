const employeesData = [
  {
    id: 1,
    firstName: 'kartik',
    lastName: 'mane',
    email: 'kartik@example.com',
    age: '10',
    gender: 'Male',
    contact: '89898889988',
    contacttype:'primary',
    date: '2019-04-11'
  },
  {
    id: 2,
    firstName: 'aathrva',
    lastName: 'pawar',
    email: 'aathrva@example.com',
    age: '12',
    gender: 'Male',
    contact: '89898889988',
    contacttype:'primary',
    date: '2019-04-17'
  },
  {
    id: 3,
    firstName: 'aanirudha',
    lastName: 'Mokashi',
    email: 'aanimokashi@example.com',
    age: '14',
    gender: 'Male',
    contact: '89898889988',
    contacttype:'primary',
    date: '2019-05-01'
  },
  {
    id: 4,
    firstName: 'shubham',
    lastName: 'Dombe',
    email: 'shubh@example.com',
    age: '16',
    gender: 'Male',
    contact: '89898889988',
    contacttype:'primary',
    date: '2019-05-03'
  },
  {
    id: 5,
    firstName: 'smaran',
    lastName: 'jirobe',
    email: 'smjirobe@example.com',
    age: '18',
    gender: 'Male',
    contact: '89898889988',
    contacttype:'primary',
    date: '2019-06-13'
  },
  {
    id: 6,
    firstName: 'sukrut',
    lastName: 'thakrey',
    email: 'sukrutthakrey@example.com',
    age: '17',
    gender: 'Male',
    contact: '89898889988',
    contacttype:'primary',
    date: '2019-07-30'
  },
  {
    id: 7,
    firstName: 'ved',
    lastName: 'barge',
    email: 'vedbarge@example.com',
    age: '15',
    gender: 'Male',
    contact: '89898889988',
    contacttype:'primary',
    date: '2019-08-15'
  },
  {
    id: 8,
    firstName: 'devansh',
    lastName: 'patil',
    email: 'devansh@example.com',
    age: '13',
    gender: 'Male',
    contact: '89898889988',
    contacttype:'primary',
    date: '2019-10-10'
  },
  {
    id: 9,
    firstName: 'harshal',
    lastName: 'bvhjhjk',
    email: 'gjhgjhh@example.com',
    age: '11',
    gender: 'Male',
    contact: '89898889988',
    contacttype:'primary',
    date: '2019-10-15'
  },
  {
    id: 10,
    firstName: 'hjjkj',
    lastName: 'jkkjjlk',
    email: 'yugiu@example.com',
    age: '22',
    gender: 'Male',
    contact: '89898889988',
    contacttype:'primary',
    date: '2020-01-15'
  }
];

export { employeesData };
